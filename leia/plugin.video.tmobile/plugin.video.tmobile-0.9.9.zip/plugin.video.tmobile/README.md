# plugin.video.tmobile

Unofficial 3rd Party T-Mobile Anywhere plugin for Kodi.