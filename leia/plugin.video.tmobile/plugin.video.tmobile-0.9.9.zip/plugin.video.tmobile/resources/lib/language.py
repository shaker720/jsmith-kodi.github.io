from resources.lib.base.language import BaseLanguage

class Language(BaseLanguage):
    pass
    
_ = Language()