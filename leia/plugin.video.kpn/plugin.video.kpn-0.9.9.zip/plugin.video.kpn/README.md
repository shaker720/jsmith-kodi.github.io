# plugin.video.kpn

Unofficial 3rd Party KPN/Telfort/XS4ALL Interactive TV plugin for Kodi.